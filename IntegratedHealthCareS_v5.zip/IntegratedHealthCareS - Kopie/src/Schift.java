import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;

public class Schift {
	
	private int id=0;
    private String key="";
	private boolean paramedicSchift=false;
	private boolean homecareStaffSchift=false;
	private  Route routeList; // the shift is a route in order to count the working hours
	private  ArrayList<ArrayList<SubJobs>> routeParts= new ArrayList<>(); // the shift is a route in order to count the working hours
	private  HashMap<String, ArrayList<SubJobs>> listParts= new HashMap<>(); // the shift is a route in order to count the working hours

	// constructor
	public Schift(Route r1, int id) {
		this.id=id;
		routeList=r1;
		if(r1.getAmountParamedic()>0) {
			paramedicSchift=true;
		}
		else {
			homecareStaffSchift=true;
		}
		// setting routes
		int people=0;
		ArrayList<SubJobs> part= null;
		
		for(SubJobs j:routeList.getSubJobsList()) {
			if(people==0) {
				part= new ArrayList<SubJobs>();
				key= "T"+id+"P"+id;
				routeParts.add(part);
				System.out.println("newRoute");
				listParts.put(key, part);
			}
			part.add(j);
			people+=j.getTotalPeople();
		}
		System.out.println("all shift are defined");
	}	


	// setters
	public void setParamedicSchift(boolean paramedicSchift) {this.paramedicSchift = paramedicSchift;}
	public void setRouteList(Route routeList) {this.routeList = routeList;}
	public void setHomecareStaffSchift(boolean homecareStaffSchift) {this.homecareStaffSchift = homecareStaffSchift;}
	public void setId(int id) {this.id = id;}


	// getters
	public boolean isParamedicSchift() {return paramedicSchift;}
	public boolean isHomecareStaffSchift() {return homecareStaffSchift;}
	public Route getRouteList() {return routeList;}
	public ArrayList<ArrayList<SubJobs>> getRouteParts() {return routeParts;}
	public HashMap<String, ArrayList<SubJobs>> getlistParts() {return listParts;}
	public int getId() {return id;}
	public String getKey() {return key;}
	
	  
	public String toString() 
	{   String s = "";
	s = s.concat("\nId: " + (key));
	s = s.concat("\n first Job: " + (routeParts.get(0).get(1)));
	s = s.concat("\n start service:" + routeParts.get(0).get(1).getstartServiceTime());
	return s;
	}

	

}
