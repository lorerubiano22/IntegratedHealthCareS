import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class DrivingRoutes {

	private Inputs inp; // input problem
	private Test test; // input problem
	private Random rn;
	private  ArrayList<Route> routeList= new ArrayList<Route>();
	private  HashMap<Integer, Couple> assignedCouples= new HashMap<>();
	private  ArrayList<Couple> subJobsList= new ArrayList<Couple>();
	private  ArrayList<Couple> subJobsHighestQualification= new ArrayList<Couple>();
	private  ArrayList<Couple> subJobsMediumQualification= new ArrayList<Couple>();
	private  ArrayList<Couple> subJobsLowestQualification= new ArrayList<Couple>();
	private  ArrayList<Couple> subJobspatients= new ArrayList<Couple>();

	public DrivingRoutes(Inputs i, Random r, Test t, ArrayList<Couple> subJobsList) {
		inp=i;
		test=t;
		rn=r;
		this.subJobsList=subJobsList;
	}

	public void generateAfeasibleSolution() {
		// 1. Initial feasible solution
		Solution initialSol= createInitialSolution();
		// a solution is a set of routes
		// 2. VNS
		// Local search



	}

	private Solution createInitialSolution() {
		Solution initialSol= new Solution();
		creationRoutes(); // create as many routes as there are vehicles
		// iteratively insert couples - here should be a destructive and constructive method 
		clasificationjob();
		settingStartServiceTime(); // late time
		iteratedInsertion();

		return initialSol;
	}

	private void settingStartServiceTime() {
		for(Couple couple:subJobsList) {
			double serviceTimePresent=couple.getPresent().getEndTime();
			double serviceTimeFuture=couple.getFuture().getEndTime();
			if(serviceTimePresent==0 ||serviceTimeFuture==0 ) {
				System.out.println("Stop");
			}
			couple.getPresent().setStartServiceTime(serviceTimePresent);
			couple.getFuture().setStartServiceTime(serviceTimeFuture);
		}
		
	}

	private void iteratedInsertion() {
		jobReq3Qualification(); // job with a qualification equal to 3
		
	}

	private void jobReq3Qualification() {
		//Parallel insertion
		for(Route r:routeList) {// Iterate over routes until the job is inserted
			for(Couple c:subJobsHighestQualification) { // Iterate over jobs
				if(!c.getJobList().isEmpty()) {
				System.out.println("\nWalking route "+ !c.getJobList().isEmpty());}
				if(!assignedCouples.containsKey(c.getIdCouple())) {
					insertionCoupleTest(c,r);
				}
			}
		}

	}

	private void insertionCoupleTest(Couple c, Route r) {
		destruccionProcedure(c,r);
		//construccionProcedure(c,r);
	}

	private void construccionProcedure(Couple c, Route r) {
		// para cada trabajo mirar si se puede insertar antes o despues de cada trabajo	
	}

	private void destruccionProcedure(Couple c, Route r) {
		Jobs present=c.getPresent();
		Jobs future=c.getFuture();
		if(r.getSubJobsList().isEmpty()) {
			r.addCouple(c);
		}
		else {

			//if(enoughVehicleCapacity(r,c)) {
			checkingJobByJob(r,c);
			//}

		}
	}



	private void checkingJobByJob(Route r, Couple c) {
		Route newRoute= copyRoute(r);
		int i=-1;
		for(Jobs j:r.getSubJobsList()) { // se recorre la lista de trabajos y se intenta insertar el trabajo presente
			i++;
			boolean earlyInsertion=isBeforeJ(j,c);
			if(earlyInsertion) {
				double arrivalTimePresentJob=computePossiblearrivalTime(c.getPresent(),j);
				if(arrivalTimePresentJob<=j.getstartServiceTime()) {
					c.getPresent().setarrivalTime(arrivalTimePresentJob);
					newRoute.getSubJobsList().add(i,c.getPresent());
					updateRouteCost(newRoute); // update Travel time, waiting time and service time
					boolean isFutureJobInserted= insertingFutureJob(newRoute,c);
					if(!isFutureJobInserted) {
						earlyInsertion=false;
					}
					else {
						// insert the list of jobs
						r=replaceRoute(r,newRoute); // the couples in the route are no eliminated
						// insert the couple
						r.getJobsList().add(c);		
						// check the information of the couple vs the information of the job
						boolean correctInf= checkInfSolution(r);
						System.out.println("\nCorrect information__"+correctInf);
					}
				}
			}
			if(!earlyInsertion && i+1<r.getSubJobsList().size()) {
				if(isAfterJ(j,c,r.getSubJobsList().get(i+1))) {
					double arrivalTimePresentJob=computePossiblearrivalTimeAfter(c.getPresent(),j);
					if(arrivalTimePresentJob<=c.getPresent().getstartServiceTime()) {
						c.getPresent().setarrivalTime(arrivalTimePresentJob);
						if(i+1<r.getSubJobsList().size()) {
							newRoute.getSubJobsList().add(i+1,c.getPresent());}
						else {
							newRoute.getSubJobsList().add(c.getPresent());}
						updateRouteCost(newRoute); // update Travel time, waiting time and service time
					}
				}
			}
		}

	}

	private Route copyRoute(Route r) {
		Route newRoute= new Route();
		for(Couple c:r.getJobsList()) {
			newRoute.addCouple(c);
		}
		return newRoute;
	}

	private Route replaceRoute(Route toClean, Route newRoute) {
		toClean.getSubJobsList().clear();
		for(Jobs j:newRoute.getSubJobsList()) {
			toClean.getSubJobsList().add(j);
		}
		updateRouteCost(toClean);
		return toClean;
	}

	private void updateRouteCost(Route newRoute) {
		double durationRoute=0;
		double travelTime=0; // update Travel time
		double serviceTime=0; //Start with the first service. service time
		// TO DO. waitingTime+=first job; // falta determinar la informaci�n del primer nodo en cada ruta
		double waitingTime=newRoute.getSubJobsList().getFirst().getWaitingTime(); //waiting time 
		for(int i=0;i<newRoute.getSubJobsList().size()-1;i++) {
			// se calculan los datos de la ruta tomando como referencia el nodo i 
			// pero se establece la infomaci�n para el nodo i+1
			Jobs iJob=newRoute.getSubJobsList().get(i);
			Jobs jJob=newRoute.getSubJobsList().get(i+1);
			double doubleDirectConnection= inp.getCarCost().getCost(iJob.getId(), jJob.getId());
			double loadTimeJobJ=0;
			if(jJob.isClient()) {
				loadTimeJobJ=test.getloadTimeHomeCareStaff();
			}
			else {
				loadTimeJobJ=test.getloadTimePatient();
			}
			double serviceTimeHJobI=newRoute.getSubJobsList().get(i).getReqTime();
			double arrivalTimeJobj=iJob.getstartServiceTime()+serviceTimeHJobI+doubleDirectConnection+loadTimeJobJ;
			jJob.setarrivalTime(arrivalTimeJobj);
			travelTime+=doubleDirectConnection; //travel time
			serviceTime+=serviceTimeHJobI; //Start with the first service. service time
			waitingTime+=jJob.getWaitingTime();  // update Travel time


		}
		serviceTime+=newRoute.getSubJobsList().getLast().getReqTime();
		newRoute.setServiceTime(serviceTime);
		newRoute.setWaitingTime(waitingTime);
		newRoute.setTravelTime(travelTime);
		durationRoute=travelTime+serviceTime+waitingTime;
		newRoute.setDurationRoute(durationRoute);
	}

	private double computePossiblearrivalTimeAfter(Jobs toInsert, Jobs inRoute) {
		double arrivalTime=0;
		double loadUnloadTime=0;
		if(toInsert.isClient()) {
			loadUnloadTime=test.getloadTimeHomeCareStaff();
		}
		else {
			loadUnloadTime=test.getloadTimePatient();
		}
		double travelTime= inp.getCarCost().getCost(inRoute.getId(),toInsert.getId());
		int previousUser=0;
		if(inRoute.isClient()) {
			previousUser=test.getloadTimeHomeCareStaff();
		}
		else {
			previousUser=test.getloadTimePatient();
		}	
		double timeAtPreviousNode=inRoute.getstartServiceTime()+inRoute.getReqTime()+previousUser;
		double previousTime=timeAtPreviousNode+travelTime+loadUnloadTime;
		arrivalTime=inRoute.getstartServiceTime()+previousTime;
		return arrivalTime;
	}

	private boolean checkInfSolution(Route r) {
		boolean correctInformation=false;
		int i=-1;
		for(Couple c:r.getJobsList()) {
			i++;
			if(c.getPresent()==r.getSubJobsList().get(i)) {
				i++;
				if(c.getFuture()==r.getSubJobsList().get(i)) {
					correctInformation=true;
					System.out.println("\nCouples Information" + c.toString());
					System.out.println("\nJob Information");
					System.out.println("\nJob Present" + c.getPresent());
					System.out.println("\nJob Future" + c.getFuture());
				}	
			}

		}
		return correctInformation;
	}




	private boolean insertingFutureJob(Route newRoute, Couple c) {
		boolean inserted= false;
		int sizeRoute=newRoute.getSubJobsList().size();
		for(int i=sizeRoute-1;i>=0;i--) { // checking backward Route
			Jobs jobI=newRoute.getSubJobsList().get(i);	
			if(lastJobFeasible(c,jobI)) { // last job
				newRoute.getSubJobsList().add(c.getFuture());
				inserted=checkReaminingRoute(newRoute); // the solution is repaired 
			}
		}
		return inserted;
	}

	private boolean checkReaminingRoute(Route newRoute) {
		// 1. Time windows

		// 2. Driving working Route

		//3. Vehicle capacity

		//4. Max. detour duration

		return false;
	}

	private boolean lastJobFeasible(Couple c, Jobs jobI) {
		boolean insertion=false;
		double directConnection = inp.getCarCost().getCost(jobI.getId(), c.getFuture().getId());
		double loadTime=0;
		if(jobI.isClient()) {
			loadTime=test.getloadTimeHomeCareStaff();
		}
		double possibelArrivalTime=jobI.getstartServiceTime()+jobI.getReqTime()+loadTime+directConnection;
		if(possibelArrivalTime>=c.getFuture().getStartTime() && possibelArrivalTime<=c.getFuture().getEndTime()) { // TW
			if(possibelArrivalTime-c.getPresent().getArrivalTime()<=test.getDetour()) { // Max detour duration
				c.getFuture().setarrivalTime(possibelArrivalTime);
				insertion=true;	
			}
		}
		return insertion;
	}

	private double computePossiblearrivalTime(Jobs toInsert, Jobs inRoute) {
		double arrivalTime=0;
		double loadUnloadTime=0;
		if(toInsert.isClient()) {
			loadUnloadTime=test.getloadTimeHomeCareStaff();
		}
		else {
			loadUnloadTime=test.getloadTimePatient();
		}
		double tarvelTime= inp.getCarCost().getCost(toInsert.getId(), inRoute.getId());
		double previousTime=loadUnloadTime+tarvelTime;
		arrivalTime=toInsert.getstartServiceTime()+previousTime;
		return arrivalTime;
	}


	private boolean isAfterJ(Jobs j, Couple c, Jobs l) {
		boolean lateJob=false;
		//if(c.getPresent().getstartServiceTime()>j.getstartServiceTime() && c.getPresent().getstartServiceTime()<l.getstartServiceTime()) {
		if(c.getPresent().getstartServiceTime()>j.getstartServiceTime() ) {
			
		lateJob=true;
		}
		return lateJob;

	}

	private boolean isBeforeJ(Jobs j, Couple c) {
		boolean earlyJob=false;
		System.out.print("\nJob to insert "+c.getPresent().getstartServiceTime());
		System.out.print("\nJob in route "+j.getstartServiceTime());
		if(c.getPresent().getstartServiceTime()<j.getstartServiceTime()) {
			earlyJob=true;
		}
		return earlyJob;
	}

	private void creationRoutes() {
		for(int i=0;i<inp.getVehicles().size();i++) {
			int idVehicle=inp.getVehicles().get(i).getId();
			Route r= new Route();
			r.setIdRoute(idVehicle);
			routeList.add(r);
		}
	}

	private void clasificationjob() {
		// 0.classified couples according the req qualification
		for(int qualification=0;qualification<=inp.getMaxQualificationLevel();qualification++) {
			for(Couple c:subJobsList) {
				if(c.getQualification()==qualification && qualification==0) {
					subJobspatients.add(c);
				}
				if(c.getQualification()==qualification && qualification==1) {
					subJobsLowestQualification.add(c);
				}
				if(c.getQualification()==qualification && qualification==2) {
					this.subJobsMediumQualification.add(c);
				}
				if(c.getQualification()==qualification && qualification==3) {
					this.subJobsHighestQualification.add(c);
				}
			}
		}
	}









}
