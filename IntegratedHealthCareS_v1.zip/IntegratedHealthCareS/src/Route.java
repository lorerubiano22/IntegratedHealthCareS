import java.util.HashMap;
import java.util.LinkedList;

public class Route {
	private int id=0;
	private double travelTime = 0.0; // travel time
	private double serviceTime = 0.0; // travel time
	private double waitingTime = 0.0; // travel time
	private double durationRoute = 0.0; // route total costs
	private float passengers = 0.0F; // route total demand
	private LinkedList<Edge> edges; // edges list
	private LinkedList<Couple> jobsList= new LinkedList<Couple>(); // subjobs list (pick up and delivary)
	private LinkedList<Jobs> subJobsList=new LinkedList<Jobs>(); // subjobs list (pick up and delivary)
	private HashMap<Integer, Couple> positionJobs=new HashMap<Integer, Couple>();
	
	

	// Setters
	public void setDurationRoute(double durationRoute) {this.durationRoute = durationRoute;}
	public void setTravelTime(double tv) {this.travelTime = tv;}
	public void setServiceTime(double st) {this.serviceTime = st;}
	public void setWaitingTime(double wt) {this.waitingTime = wt;}
	public void setPassengers(float passengers) {this.passengers = passengers;}
	public void setEdges(LinkedList<Edge> edges) {this.edges = edges;}
	public void setJobsList(LinkedList<Couple> JobsList) {this.jobsList = JobsList;}
	public void setSubJobsList(LinkedList<Jobs> subJobsList) {this.subJobsList = subJobsList;}
	public void setIdRoute(int idVehicle) { id=idVehicle;}

	// Getters
	public double getDurationRoute() {return durationRoute;}
	public double getServiceTime() {return serviceTime;}
	public double getWaitingTime() {return waitingTime;}
	public double getTravelTime() {return travelTime;}
	public int getIdRoute() {return id;}
	public float getPassengers() {return passengers;}
	public LinkedList<Couple> getJobsList() {return jobsList;}
	public LinkedList<Jobs> getSubJobsList() {return subJobsList;}
	public LinkedList<Edge> getEdges() {return edges;}
	public void addCouple(Couple c) {
		jobsList.add(c); // this couple has to have updated the times (service start time, arrival)
		subJobsList.add(c.getPresent());
		subJobsList.add(c.getFuture());
	}
	




}
